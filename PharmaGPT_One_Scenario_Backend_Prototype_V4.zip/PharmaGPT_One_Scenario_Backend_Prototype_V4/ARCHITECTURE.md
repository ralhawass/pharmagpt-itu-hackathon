# Prototype Architecture

```text
Browser interface
      |
      | POST /api/analyze
      v
Python backend
      |
      +--> Load packaged JSON knowledge base
      +--> Normalize target product profile
      +--> Retrieve and rank condition-aware records
      +--> Resolve source titles, locators, URLs, tiers, and limitations
      +--> Generate evidence-backed candidate pathways
      +--> Apply hard filters F3 and F5
      +--> Build prioritized experiment plan
      |
      v
Structured JSON response
      |
      +--> Ranked candidates
      +--> Retrieved knowledge records
      +--> Policy guardrails
      +--> Experimental plan
      +--> Y.3172 conceptual trace
```

## Y.3172 conceptual mapping shown in the prototype

| Stage | Prototype implementation |
|---|---|
| SRC | Packaged PharmaGPT JSON source registry and pharmaceutical records |
| C | POST request and record-collection selection |
| PP | Identity and target-product-profile normalization |
| M | Transparent rule-based evidence retrieval and candidate ranking |
| P | Evidence limits, shelf-life refusal, and human approval controls |
| D | Structured JSON analysis package and visual report |
| SINK | Qualified formulation scientist reviewing the plan |

This is an application-level conceptual adaptation, not a claim of formal telecommunications conformance.
