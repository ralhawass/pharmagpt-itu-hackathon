# PharmaGPT One-Scenario Backend Prototype V4

This focused prototype demonstrates one complete application scenario:

> Develop a long-acting subcutaneous exenatide formulation using a PLGA depot platform.

The interface sends a target product profile to a real Python backend. The backend searches the packaged PharmaGPT machine-readable knowledge base, resolves source metadata, ranks formulation pathways, triggers scientific and policy guardrails, and returns a structured experimental plan.

## What proves that it uses the knowledge base

- The backend loads `data/knowledge_base.json`, the packaged PharmaGPT V1.1 machine-readable knowledge base.
- Every analysis response includes the knowledge-base version and SHA-256 checksum.
- The interface displays the exact retrieved record IDs, claims, conditions, evidence tiers, source locators, limitations, and public source links.
- Candidate pathways show the specific knowledge records used in their ranking.
- The shelf-life claim is blocked using hard filter `F3` from the knowledge base.
- Qualified human approval is required using hard filter `F5`.

## Run it

No external Python packages are required.

### macOS or Linux

```bash
cd PharmaGPT_One_Scenario_Backend_Prototype_V4
python3 app.py
```

Or double-click `start_mac.command` on macOS.

### Windows

Double-click `start_windows.bat`, or run:

```bat
python app.py
```

Open: `http://127.0.0.1:8000`

Use a different port with:

```bash
python3 app.py 8080
```

## API endpoints

- `GET /api/health`: confirms the backend and knowledge-base checksum.
- `GET /api/scenario`: returns the demonstration scenario.
- `POST /api/analyze`: retrieves evidence and returns ranked candidates, guardrails, experiments, and the Y.3172 conceptual trace.

Example request:

```json
{
  "active_ingredient": "Exenatide",
  "route": "Subcutaneous injection",
  "dosage_form": "Extended-release injectable microspheres",
  "platform": "PLGA depot",
  "release_target_days": 28,
  "primary_concern": "Peptide acylation and chemical degradation",
  "desired_shelf_life_months": 24
}
```

## Important boundary

This is a hackathon scenario demonstration. The retrieval and ranking logic is deterministic and transparent, but it is not a validated formulation model. The output is a set of testable hypotheses. Laboratory confirmation and qualified scientific review remain mandatory.
