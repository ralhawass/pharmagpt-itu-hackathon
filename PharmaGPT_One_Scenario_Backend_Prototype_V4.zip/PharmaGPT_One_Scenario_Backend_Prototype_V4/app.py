#!/usr/bin/env python3
"""PharmaGPT focused scenario prototype.

A dependency-free Python backend that serves a single exenatide formulation
scenario and retrieves evidence from the packaged PharmaGPT knowledge base.

Run:
    python app.py
Then open:
    http://127.0.0.1:8000
"""

from __future__ import annotations

import hashlib
import json
import mimetypes
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
KB_PATH = ROOT / "data" / "knowledge_base.json"


def load_knowledge_base() -> tuple[dict[str, Any], str]:
    raw = KB_PATH.read_bytes()
    kb = json.loads(raw.decode("utf-8"))
    checksum = hashlib.sha256(raw).hexdigest()
    return kb, checksum


KB, KB_CHECKSUM = load_knowledge_base()
SOURCE_INDEX = {item["id"]: item for item in KB.get("source_registry", [])}
PHARMA_RECORDS = (
    KB.get("record_collections", {})
    .get("pharmaceutical_knowledge_records", {})
    .get("records", [])
)
HARD_FILTERS = {
    item["id"]: item for item in KB.get("readiness_configuration", {}).get("hard_filters", [])
}


TOKEN_RE = re.compile(r"[a-z0-9]+(?:[-'][a-z0-9]+)?", re.IGNORECASE)
STOPWORDS = {
    "a", "an", "and", "the", "to", "of", "for", "in", "on", "with", "or", "as",
    "is", "are", "be", "by", "from", "using", "use", "into", "its", "it", "at",
}


def normalize_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def tokens(value: Any) -> set[str]:
    return {m.group(0).lower() for m in TOKEN_RE.finditer(str(value or "")) if m.group(0).lower() not in STOPWORDS}


def source_ids(raw_source: str) -> list[str]:
    """Expand simple source values such as S43 or S48-S49 where possible."""
    raw_source = str(raw_source or "").strip()
    if re.fullmatch(r"S\d{2}", raw_source):
        return [raw_source]
    match = re.fullmatch(r"S(\d{2})-S?(\d{2})", raw_source)
    if match:
        start, end = map(int, match.groups())
        return [f"S{i:02d}" for i in range(start, end + 1)]
    return [part.strip() for part in raw_source.split(",") if part.strip()]


def attach_sources(record: dict[str, Any]) -> dict[str, Any]:
    enriched = dict(record)
    resolved = []
    for sid in source_ids(record.get("source", "")):
        source = SOURCE_INDEX.get(sid)
        if source:
            resolved.append({
                "id": source.get("id"),
                "title": source.get("title"),
                "authority": source.get("authority"),
                "type": source.get("type"),
                "url": source.get("url"),
            })
    enriched["sources"] = resolved
    return enriched


@dataclass(frozen=True)
class Scenario:
    active_ingredient: str
    route: str
    dosage_form: str
    platform: str
    release_target_days: int
    primary_concern: str
    desired_shelf_life_months: int | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "Scenario":
        active = str(payload.get("active_ingredient", "Exenatide")).strip()
        if normalize_text(active) != "exenatide":
            raise ValueError("This focused prototype currently supports the exenatide scenario only.")

        try:
            release_days = int(payload.get("release_target_days", 28))
        except (TypeError, ValueError):
            release_days = 28
        release_days = max(1, min(release_days, 90))

        shelf_raw = payload.get("desired_shelf_life_months", 24)
        try:
            shelf = int(shelf_raw) if shelf_raw not in (None, "") else None
        except (TypeError, ValueError):
            shelf = None
        if shelf is not None:
            shelf = max(1, min(shelf, 60))

        return cls(
            active_ingredient=active,
            route=str(payload.get("route", "Subcutaneous injection")).strip(),
            dosage_form=str(payload.get("dosage_form", "Extended-release injectable microspheres")).strip(),
            platform=str(payload.get("platform", "PLGA depot")).strip(),
            release_target_days=release_days,
            primary_concern=str(payload.get("primary_concern", "Peptide acylation and chemical degradation")).strip(),
            desired_shelf_life_months=shelf,
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "active_ingredient": self.active_ingredient,
            "route": self.route,
            "dosage_form": self.dosage_form,
            "platform": self.platform,
            "release_target_days": self.release_target_days,
            "primary_concern": self.primary_concern,
            "desired_shelf_life_months": self.desired_shelf_life_months,
        }


def record_text(record: dict[str, Any]) -> str:
    return " ".join(str(record.get(field, "")) for field in (
        "subject", "category", "claim", "context", "use", "limitation"
    ))


def retrieval_score(record: dict[str, Any], scenario: Scenario) -> tuple[float, list[str]]:
    text = normalize_text(record_text(record))
    rec_tokens = tokens(text)
    query_text = " ".join([
        scenario.active_ingredient,
        scenario.route,
        scenario.dosage_form,
        scenario.platform,
        scenario.primary_concern,
        "extended release long acting microsphere polymer stabilizer degradation moisture pH adsorption",
    ])
    query_tokens = tokens(query_text)
    overlap = rec_tokens & query_tokens

    score = float(len(overlap))
    reasons: list[str] = []

    if "exenatide" in text:
        score += 8
        reasons.append("direct exenatide evidence")
    if "plga" in text or "polylactide-co-glycolide" in text:
        score += 5
        reasons.append("direct PLGA relevance")
    if any(term in text for term in ("acylation", "degradation", "oxidation", "deamidation")):
        score += 3.5
        reasons.append("addresses the primary degradation concern")
    if any(term in text for term in ("extended-release", "extended release", "long-acting", "microsphere")):
        score += 3
        reasons.append("matches the long-acting product target")
    if any(term in text for term in ("stabilizer", "sucrose", "poloxamer", "proline", "lysine", "phenylalanine")):
        score += 2.5
        reasons.append("supports stabilizer or adsorption-control screening")
    if any(term in text for term in ("moisture", "relative humidity", "pH", "polymer selection")):
        score += 2
        reasons.append("supports risk-control or polymer selection")

    tier = normalize_text(record.get("evidence_tier"))
    if tier == "tier 1":
        score += 1.5
    elif tier == "tier 2":
        score += 1.0

    if overlap:
        reasons.append(f"{len(overlap)} query terms matched")

    return round(score, 2), reasons


def retrieve_records(scenario: Scenario, limit: int = 14) -> list[dict[str, Any]]:
    ranked = []
    for record in PHARMA_RECORDS:
        score, reasons = retrieval_score(record, scenario)
        if score > 4:
            enriched = attach_sources(record)
            enriched["retrieval_score"] = score
            enriched["retrieval_reasons"] = reasons
            ranked.append(enriched)
    ranked.sort(key=lambda item: (-item["retrieval_score"], item.get("id", "")))
    return ranked[:limit]


def select_records(retrieved: list[dict[str, Any]], ids: list[str]) -> list[dict[str, Any]]:
    index = {record.get("id"): record for record in retrieved}
    return [index[rid] for rid in ids if rid in index]


def evidence_points(records: list[dict[str, Any]]) -> float:
    points = 0.0
    for record in records:
        tier = normalize_text(record.get("evidence_tier"))
        points += 8 if tier == "tier 1" else 6 if tier == "tier 2" else 3
    return min(points, 40)


def candidate_score(records: list[dict[str, Any]], directness: int, risk_control: int, feasibility: int) -> dict[str, Any]:
    evidence = evidence_points(records)
    total = min(100, round(evidence + directness + risk_control + feasibility))
    return {
        "total": total,
        "breakdown": {
            "evidence_strength": round(evidence),
            "scenario_directness": directness,
            "risk_control": risk_control,
            "development_feasibility": feasibility,
        },
    }


def make_candidates(retrieved: list[dict[str, Any]], scenario: Scenario) -> list[dict[str, Any]]:
    candidate_specs = [
        {
            "title": "PLGA depot with sucrose and adsorption-control screening",
            "ids": ["KB-003", "KB-004", "KB-005", "KB-011", "KB-013", "KB-014"],
            "directness": 23,
            "risk_control": 18,
            "feasibility": 13,
            "rationale": (
                "Start from the marketed PLGA depot precedent, then screen sucrose for process-related protection "
                "and poloxamer 188 or selected amino acids for adsorption control. Monitor acylation, oxidation, "
                "and deamidation rather than assuming the precedent transfers to a new composition."
            ),
            "main_risk": "Peptide acylation and degradation during encapsulation and release.",
            "decision": "Highest-priority laboratory pathway",
        },
        {
            "title": "Acidic-microenvironment PLGA strategy with moisture control",
            "ids": ["KB-004", "KB-005", "KB-007", "KB-008", "KB-010", "KB-013"],
            "directness": 22,
            "risk_control": 19,
            "feasibility": 11,
            "rationale": (
                "Prioritize an acidic internal environment and controlled water exposure because the retrieved "
                "records associate higher pH and absorbed water with greater acylation. Screen polymer molecular "
                "weight and concentration rather than treating one PLGA grade as universally optimal."
            ),
            "main_risk": "Condition-specific findings may not reproduce in finished microspheres.",
            "decision": "Strong risk-mitigation pathway",
        },
        {
            "title": "Comparative polymer screen: PLGA 75:25 or PLA versus PLGA 50:50",
            "ids": ["KB-004", "KB-006", "KB-009", "KB-010"],
            "directness": 20,
            "risk_control": 15,
            "feasibility": 12,
            "rationale": (
                "Use the solution-model evidence as a screening prior, not as a finished-product rule. Compare "
                "polymer composition, molecular weight, and loading while measuring release and degradation against "
                f"the {scenario.release_target_days}-day target."
            ),
            "main_risk": "The polymer evidence comes partly from a simplified mixed-solvent model.",
            "decision": "Comparative fallback and learning arm",
        },
    ]

    candidates = []
    for rank, spec in enumerate(candidate_specs, start=1):
        records = select_records(retrieved, spec["ids"])
        score = candidate_score(records, spec["directness"], spec["risk_control"], spec["feasibility"])
        candidates.append({
            "rank": rank,
            "title": spec["title"],
            "score": score["total"],
            "score_breakdown": score["breakdown"],
            "decision": spec["decision"],
            "rationale": spec["rationale"],
            "main_risk": spec["main_risk"],
            "evidence_record_ids": [r["id"] for r in records],
            "evidence_count": len(records),
            "evidence_summary": [
                {
                    "id": r.get("id"),
                    "claim": r.get("claim"),
                    "tier": r.get("evidence_tier"),
                    "source": r.get("source"),
                    "limitation": r.get("limitation"),
                }
                for r in records
            ],
        })
    return candidates


def make_experiment_plan() -> list[dict[str, Any]]:
    return [
        {
            "step": 1,
            "experiment": "Polymer and formulation matrix screen",
            "decision_question": "Which polymer composition, molecular weight, and stabilizer combination gives the best starting balance?",
            "measurements": ["Encapsulation efficiency", "particle size", "drug recovery", "initial impurities"],
            "evidence_record_ids": ["KB-003", "KB-009", "KB-010", "KB-011"],
        },
        {
            "step": 2,
            "experiment": "Interface and adsorption-control study",
            "decision_question": "Can surface and emulsion-interface losses be reduced?",
            "measurements": ["Free peptide", "surface adsorption", "recovery after processing", "visible and subvisible particles"],
            "evidence_record_ids": ["KB-012", "KB-013", "KB-014"],
        },
        {
            "step": 3,
            "experiment": "Stability-indicating degradation study",
            "decision_question": "Which candidate best controls acylation, oxidation, and deamidation?",
            "measurements": ["UPLC assay", "LC-MS impurity identification", "acylated species", "oxidized and deamidated species"],
            "evidence_record_ids": ["KB-004", "KB-005"],
        },
        {
            "step": 4,
            "experiment": "pH and moisture stress matrix",
            "decision_question": "How do internal pH and water exposure alter chemical stability?",
            "measurements": ["Water uptake", "glass-transition proxy", "impurity growth", "peptide recovery"],
            "evidence_record_ids": ["KB-007", "KB-008"],
        },
        {
            "step": 5,
            "experiment": "In-vitro release comparison",
            "decision_question": "Which candidate approaches the intended long-acting profile without excessive burst or lag?",
            "measurements": ["Initial burst", "lag phase", "cumulative release", "mass balance", "released-peptide integrity"],
            "evidence_record_ids": ["KB-006"],
        },
        {
            "step": 6,
            "experiment": "Candidate-specific stability programme",
            "decision_question": "What additional data are required before any shelf-life statement can be considered?",
            "measurements": ["Long-term stability", "accelerated stability", "container interaction", "sterility and quality attributes as applicable"],
            "evidence_record_ids": ["F3"],
        },
    ]


def analyze(payload: dict[str, Any]) -> dict[str, Any]:
    scenario = Scenario.from_payload(payload)
    retrieved = retrieve_records(scenario)
    candidates = make_candidates(retrieved, scenario)

    category_counts: dict[str, int] = {}
    tier_counts: dict[str, int] = {}
    for record in retrieved:
        category = record.get("category", "Other")
        category_counts[category] = category_counts.get(category, 0) + 1
        tier = record.get("evidence_tier", "Unclassified")
        tier_counts[tier] = tier_counts.get(tier, 0) + 1

    triggered_guardrails = []
    if scenario.desired_shelf_life_months:
        rule = HARD_FILTERS.get("F3", {
            "id": "F3",
            "trigger": "Shelf-life statement without formulation-specific time-course data",
            "action": "Refuse expiry assignment and propose study",
        })
        triggered_guardrails.append({
            **rule,
            "status": "BLOCKED",
            "message": (
                f"A {scenario.desired_shelf_life_months}-month shelf life cannot be assigned from the retrieved "
                "precedent and short-duration evidence. Candidate-specific stability data are required."
            ),
        })

    rule_f5 = HARD_FILTERS.get("F5", {
        "id": "F5",
        "trigger": "Missing qualified reviewer or release gate",
        "action": "Prevent operational approval",
    })
    triggered_guardrails.append({
        **rule_f5,
        "status": "HUMAN REVIEW REQUIRED",
        "message": "The ranked strategies are testable hypotheses. A qualified formulation scientist must approve the experimental plan.",
    })

    package_summary = KB.get("package_summary", {})
    trace = [
        {
            "stage": "SRC",
            "name": "Source",
            "detail": f"Loaded {package_summary.get('authenticated_public_sources', len(SOURCE_INDEX))} authenticated public sources and {len(PHARMA_RECORDS)} pharmaceutical records from the packaged JSON knowledge base.",
            "status": "complete",
        },
        {
            "stage": "C",
            "name": "Collector",
            "detail": "Received the target product profile through POST /api/analyze and selected the pharmaceutical record collection.",
            "status": "complete",
        },
        {
            "stage": "PP",
            "name": "Preprocessor",
            "detail": f"Normalized active ingredient, route, dosage form, platform, release target, concern, and shelf-life request. Identity resolved to {scenario.active_ingredient}.",
            "status": "complete",
        },
        {
            "stage": "M",
            "name": "Model",
            "detail": f"Rule-based retrieval ranked {len(retrieved)} records and generated {len(candidates)} evidence-backed development pathways.",
            "status": "complete",
        },
        {
            "stage": "P",
            "name": "Policy",
            "detail": f"Applied {len(triggered_guardrails)} release controls, including the shelf-life refusal rule and mandatory human approval.",
            "status": "complete",
        },
        {
            "stage": "D",
            "name": "Distributor",
            "detail": "Packaged ranked candidates, evidence locators, limitations, guardrails, and the experimental plan as a structured JSON response.",
            "status": "complete",
        },
        {
            "stage": "SINK",
            "name": "Sink",
            "detail": "Formulation scientist reviews the evidence and decides which experiments may proceed.",
            "status": "pending human review",
        },
    ]

    return {
        "request_id": f"PGPT-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "prototype_status": "Scenario demonstration, not a validated formulation model or product approval system",
        "scenario": scenario.as_dict(),
        "decision_summary": {
            "recommended_pathway": candidates[0]["title"],
            "why": "It combines direct marketed precedent with exenatide-specific degradation evidence and stabilizer-screening records.",
            "next_action": "Approve and run the prioritized six-step laboratory plan.",
            "claim_boundary": "No candidate is confirmed until laboratory testing and qualified review are complete.",
        },
        "knowledge_base": {
            "file": KB_PATH.name,
            "title": KB.get("title"),
            "version": KB.get("version"),
            "last_verified": KB.get("last_verified"),
            "sha256": KB_CHECKSUM,
            "authenticated_public_sources": package_summary.get("authenticated_public_sources", len(SOURCE_INDEX)),
            "pharmaceutical_records": package_summary.get("pharmaceutical_knowledge_records", len(PHARMA_RECORDS)),
            "ai_readiness_records": package_summary.get("ai_readiness_knowledge_records", 0),
            "retrieved_record_count": len(retrieved),
            "retrieved_category_counts": category_counts,
            "retrieved_tier_counts": tier_counts,
        },
        "ranked_candidates": candidates,
        "guardrails": triggered_guardrails,
        "experiment_plan": make_experiment_plan(),
        "retrieved_records": retrieved,
        "pipeline_trace": trace,
    }


class PharmaGPTHandler(SimpleHTTPRequestHandler):
    server_version = "PharmaGPTPrototype/4.0"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stdout.write(f"[{datetime.now().isoformat(timespec='seconds')}] {self.address_string()} {fmt % args}\n")

    def send_json(self, payload: dict[str, Any], status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            package_summary = KB.get("package_summary", {})
            self.send_json({
                "status": "ok",
                "backend": "Python standard-library HTTP API",
                "prototype_version": "4.0",
                "knowledge_base": {
                    "file": KB_PATH.name,
                    "version": KB.get("version"),
                    "sha256": KB_CHECKSUM,
                    "authenticated_public_sources": package_summary.get("authenticated_public_sources", len(SOURCE_INDEX)),
                    "pharmaceutical_records": package_summary.get("pharmaceutical_knowledge_records", len(PHARMA_RECORDS)),
                    "ai_readiness_records": package_summary.get("ai_readiness_knowledge_records", 0),
                },
            })
            return
        if parsed.path == "/api/scenario":
            self.send_json({
                "active_ingredient": "Exenatide",
                "route": "Subcutaneous injection",
                "dosage_form": "Extended-release injectable microspheres",
                "platform": "PLGA depot",
                "release_target_days": 28,
                "primary_concern": "Peptide acylation and chemical degradation",
                "desired_shelf_life_months": 24,
            })
            return
        if parsed.path.startswith("/api/"):
            self.send_json({"error": "API endpoint not found"}, status=404)
            return
        if parsed.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/api/analyze":
            self.send_json({"error": "API endpoint not found"}, status=404)
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length > 100_000:
                self.send_json({"error": "Request is too large"}, status=413)
                return
            raw = self.rfile.read(content_length)
            payload = json.loads(raw.decode("utf-8") or "{}")
            if not isinstance(payload, dict):
                raise ValueError("Request body must be a JSON object.")
            result = analyze(payload)
            self.send_json(result)
        except json.JSONDecodeError:
            self.send_json({"error": "Invalid JSON request body."}, status=400)
        except ValueError as exc:
            self.send_json({"error": str(exc)}, status=400)
        except Exception as exc:  # defensive prototype boundary
            self.send_json({"error": f"Backend processing failed: {exc}"}, status=500)


def main() -> None:
    host = "127.0.0.1"
    port = 8000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            raise SystemExit("Port must be an integer, for example: python app.py 8080")
    mimetypes.add_type("application/javascript", ".js")
    server = ThreadingHTTPServer((host, port), PharmaGPTHandler)
    print("PharmaGPT one-scenario backend prototype")
    print(f"Knowledge base: {KB_PATH.name} (SHA-256 {KB_CHECKSUM[:12]}...)")
    print(f"Open http://{host}:{port}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
