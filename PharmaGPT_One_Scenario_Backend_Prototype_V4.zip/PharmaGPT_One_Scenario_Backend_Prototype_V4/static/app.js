'use strict';

const state = { result: null, health: null };
const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value ?? '')
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#039;');

function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  window.setTimeout(() => element.classList.remove('show'), 2400);
}

async function requestJSON(url, options = {}) {
  const response = await fetch(url, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Request failed (${response.status})`);
  return payload;
}

async function connectBackend() {
  const status = $('#backendStatus');
  try {
    const health = await requestJSON('/api/health');
    state.health = health;
    status.innerHTML = '<span class="status-dot live"></span>Backend connected';
    $('#backendType').textContent = health.backend;
    $('#kbFile').textContent = health.knowledge_base.file;
    $('#kbVersion').textContent = `Version ${health.knowledge_base.version}`;
    $('#kbHash').textContent = `${health.knowledge_base.sha256.slice(0, 16)}…`;
    const kpis = $('#heroKpis').querySelectorAll('strong');
    kpis[0].textContent = health.knowledge_base.authenticated_public_sources;
    kpis[1].textContent = health.knowledge_base.pharmaceutical_records;
    kpis[2].textContent = health.knowledge_base.ai_readiness_records;
  } catch (error) {
    status.innerHTML = '<span class="status-dot error"></span>Backend unavailable';
    toast('Start the backend with: python app.py');
  }
}

function formPayload() {
  return {
    active_ingredient: $('#activeIngredient').value,
    route: $('#route').value,
    dosage_form: $('#dosageForm').value,
    platform: $('#platform').value,
    release_target_days: Number($('#releaseTarget').value),
    primary_concern: $('#primaryConcern').value,
    desired_shelf_life_months: Number($('#shelfLife').value),
  };
}

const progressMessages = [
  'Resolving the active ingredient and target product profile…',
  'Searching condition-aware pharmaceutical records…',
  'Ranking direct and analogous evidence…',
  'Applying shelf-life and human-review guardrails…',
  'Building the experimental decision plan…',
];

function startProgress() {
  const panel = $('#processingPanel');
  const bar = $('#progressBar');
  const text = $('#processingText');
  panel.hidden = false;
  let index = 0;
  bar.style.width = '8%';
  text.textContent = progressMessages[0];
  const timer = window.setInterval(() => {
    index = Math.min(index + 1, progressMessages.length - 1);
    text.textContent = progressMessages[index];
    bar.style.width = `${18 + index * 19}%`;
  }, 350);
  return () => {
    window.clearInterval(timer);
    bar.style.width = '100%';
    text.textContent = 'Structured response received from backend.';
    window.setTimeout(() => { panel.hidden = true; }, 350);
  };
}

function renderMetrics(result) {
  const kb = result.knowledge_base;
  const tierText = Object.entries(kb.retrieved_tier_counts).map(([k, v]) => `${v} ${k}`).join(' · ');
  const categories = Object.keys(kb.retrieved_category_counts).length;
  $('#retrievalMetrics').innerHTML = `
    <div class="metric-card"><span>Retrieved records</span><strong>${kb.retrieved_record_count}</strong><small>Selected from ${kb.pharmaceutical_records} pharmaceutical records</small></div>
    <div class="metric-card"><span>Evidence strength</span><strong>${escapeHtml(tierText || '—')}</strong><small>Regulatory and experimental evidence remain distinguishable</small></div>
    <div class="metric-card"><span>Evidence categories</span><strong>${categories}</strong><small>Identity, precedent, degradation, release, moisture, pH, polymer and stabilizers</small></div>
    <div class="metric-card"><span>Guardrails triggered</span><strong>${result.guardrails.length}</strong><small>Shelf-life restriction and qualified human review</small></div>
  `;
}

function renderCandidates(candidates) {
  $('#candidateList').innerHTML = candidates.map((candidate) => {
    const breakdown = Object.entries(candidate.score_breakdown).map(([key, value]) => `
      <div><span>${escapeHtml(key.replaceAll('_', ' '))}</span><strong>${value}</strong></div>
    `).join('');
    const ids = candidate.evidence_record_ids.map((id) => `<span>${escapeHtml(id)}</span>`).join('');
    return `
      <article class="candidate-card">
        <div class="candidate-top">
          <div class="rank-box">0${candidate.rank}</div>
          <div><h4>${escapeHtml(candidate.title)}</h4><div class="candidate-decision">${escapeHtml(candidate.decision)} · ${candidate.evidence_count} supporting records</div></div>
          <div class="score-box"><strong>${candidate.score}</strong><span>/ 100</span></div>
        </div>
        <div class="candidate-body">
          <p>${escapeHtml(candidate.rationale)}</p>
          <div class="risk-box"><strong>Main limitation:</strong> ${escapeHtml(candidate.main_risk)}</div>
          <div class="score-breakdown">${breakdown}</div>
          <div class="evidence-id-list">${ids}</div>
        </div>
      </article>
    `;
  }).join('');
}

function renderGuardrails(guardrails) {
  $('#guardrailList').innerHTML = guardrails.map((guardrail) => {
    const review = guardrail.status.includes('HUMAN') ? ' review' : '';
    return `
      <article class="guardrail-card${review}">
        <div class="guardrail-head"><strong>${escapeHtml(guardrail.id)} · ${escapeHtml(guardrail.trigger)}</strong><span class="status">${escapeHtml(guardrail.status)}</span></div>
        <p>${escapeHtml(guardrail.message)}</p>
        <small>Action: ${escapeHtml(guardrail.action)}</small>
      </article>
    `;
  }).join('');
}

function renderExperiments(experiments) {
  $('#experimentPlan').innerHTML = experiments.map((item) => `
    <article class="experiment-card">
      <div class="experiment-number">${item.step}</div>
      <h4>${escapeHtml(item.experiment)}</h4>
      <p>${escapeHtml(item.decision_question)}</p>
      <ul class="measurement-list">${item.measurements.map((m) => `<li>${escapeHtml(m)}</li>`).join('')}</ul>
      <div class="experiment-evidence">Evidence: ${item.evidence_record_ids.map(escapeHtml).join(', ')}</div>
    </article>
  `).join('');
}

function renderEvidence(records) {
  $('#retrievalCount').textContent = `${records.length} records returned by POST /api/analyze`;
  $('#evidenceRecords').innerHTML = records.map((record, index) => {
    const sourceLinks = (record.sources || []).map((source) => `
      <a href="${escapeHtml(source.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(source.id)} · ${escapeHtml(source.title)}</a>
    `).join('');
    return `
      <article class="evidence-card${index < 2 ? ' open' : ''}">
        <button class="evidence-summary" type="button" aria-expanded="${index < 2}">
          <span class="record-id">${escapeHtml(record.id)}</span>
          <span class="record-subject">${escapeHtml(record.subject)} · ${escapeHtml(record.category)}</span>
          <span class="record-claim">${escapeHtml(record.claim)}</span>
          <span class="tier-chip">${escapeHtml(record.evidence_tier)}</span>
          <span class="chevron">⌄</span>
        </button>
        <div class="evidence-detail">
          <div class="detail-block"><b>Context and conditions</b><span>${escapeHtml(record.context)}</span></div>
          <div class="detail-block"><b>System use</b><span>${escapeHtml(record.use)}</span></div>
          <div class="detail-block"><b>Limitation</b><span>${escapeHtml(record.limitation)}</span></div>
          <div class="detail-block"><b>Source locator</b><span>${escapeHtml(record.source)} · ${escapeHtml(record.locator)}</span></div>
          <div class="detail-block"><b>Retrieval score</b><span>${record.retrieval_score} · ${record.retrieval_reasons.map(escapeHtml).join('; ')}</span></div>
          <div class="source-links">${sourceLinks || '<span>No public URL resolved</span>'}</div>
        </div>
      </article>
    `;
  }).join('');

  document.querySelectorAll('.evidence-summary').forEach((button) => {
    button.addEventListener('click', () => {
      const card = button.closest('.evidence-card');
      card.classList.toggle('open');
      button.setAttribute('aria-expanded', String(card.classList.contains('open')));
    });
  });
}

function renderTrace(trace) {
  $('#pipelineTrace').innerHTML = trace.map((node) => `
    <article class="trace-node">
      <span class="trace-code">${escapeHtml(node.stage)}</span>
      <h4>${escapeHtml(node.name)}</h4>
      <p>${escapeHtml(node.detail)}</p>
      <span class="trace-status">${escapeHtml(node.status)}</span>
    </article>
  `).join('');
}

function renderResult(result) {
  state.result = result;
  $('#recommendedPathway').textContent = result.decision_summary.recommended_pathway;
  $('#decisionWhy').textContent = result.decision_summary.why;
  $('#nextAction').textContent = result.decision_summary.next_action;
  $('#prototypeStatus').textContent = result.prototype_status;
  renderMetrics(result);
  renderCandidates(result.ranked_candidates);
  renderGuardrails(result.guardrails);
  renderExperiments(result.experiment_plan);
  renderEvidence(result.retrieved_records);
  renderTrace(result.pipeline_trace);
  $('#results').hidden = false;
  $('#results').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

$('#scenarioForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = $('#runButton');
  button.disabled = true;
  const finishProgress = startProgress();
  try {
    const result = await requestJSON('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formPayload()),
    });
    await new Promise((resolve) => setTimeout(resolve, 900));
    finishProgress();
    renderResult(result);
    toast(`${result.knowledge_base.retrieved_record_count} knowledge records retrieved`);
  } catch (error) {
    finishProgress();
    toast(error.message);
  } finally {
    button.disabled = false;
  }
});

$('#downloadButton').addEventListener('click', () => {
  if (!state.result) return;
  const blob = new Blob([JSON.stringify(state.result, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${state.result.request_id}-PharmaGPT-analysis.json`;
  link.click();
  URL.revokeObjectURL(url);
  toast('Structured backend report downloaded');
});

connectBackend();
