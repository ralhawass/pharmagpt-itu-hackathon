import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import Scenario, analyze, retrieve_records  # noqa: E402


class PrototypeTests(unittest.TestCase):
    def test_exenatide_retrieval_uses_real_records(self):
        scenario = Scenario.from_payload({})
        records = retrieve_records(scenario)
        ids = {record["id"] for record in records}
        self.assertIn("KB-003", ids)
        self.assertIn("KB-004", ids)
        self.assertIn("KB-008", ids)

    def test_response_contains_guardrails_and_sources(self):
        result = analyze({"desired_shelf_life_months": 24})
        self.assertTrue(any(item["id"] == "F3" for item in result["guardrails"]))
        self.assertTrue(result["retrieved_records"])
        self.assertTrue(any(record.get("sources") for record in result["retrieved_records"]))
        self.assertEqual(result["ranked_candidates"][0]["rank"], 1)

    def test_non_exenatide_is_rejected(self):
        with self.assertRaises(ValueError):
            Scenario.from_payload({"active_ingredient": "Metformin"})


if __name__ == "__main__":
    unittest.main()
